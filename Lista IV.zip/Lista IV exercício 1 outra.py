from random import randint
vetor = [randint(1, 100) for k in range(10)]
print ('Vetor:', vetor)
print ('Maior: %d' %max(vetor))
print ('Menor: %d' %min(vetor))
