print ('Bem vindo!')
g = input ('Chute um número: ')
chute = int(g)
if chute == 42:
    print ('Você venceu!')
else:
    print ('Você perdeu!')
print ('Fim do jogo!')

