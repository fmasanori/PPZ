f = open('surf.txt')
for linha in f:
    print(linha.strip())
f.close()
