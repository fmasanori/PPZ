c = float(input('Celsius: '))
f = 9*c/5 + 32
print ('%.2f Fahrenheit' %f)
