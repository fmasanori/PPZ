km = float(input('Km rodados: '))
dias = int(input('Dias: '))
preço = 60*dias + 0.15*km
print ('R$ %.2f' %preço)
