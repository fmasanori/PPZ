m = int(input('Metros: '))
print ('Milímetros: ', m*1000)
