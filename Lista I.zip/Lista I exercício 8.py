f = float(input('Fahrenheit: '))
c = (f - 32) * 5 / 9
print ('%.2f Celsius' %c)
