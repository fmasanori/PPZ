texto = '''

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Afterfest</title>
	<meta http-equiv="Content-Type"         content="text/html; charset=utf-8" /> 
    <meta content="all"                     name="robots" /> 
    <meta http-equiv="content-language"     content="portuguese" /> 
    <meta content="br"                      name="geo.country" /> 
    <meta content="true"                    name="MSSmartTagsPreventParsing" /> 
    <meta http-equiv="imagetoolbar"         content="no" /> 
    <meta content="1 days"                  name="revisit-after" /> 
    <meta content="afterfest, fotos afterfest, cobertura, cobertura afterfest, fotos balada, fotos festa, loft, areia"      name="keywords" /> 
    <meta content="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013"   name="description" /> 
	<meta property="fb:app_id" content="156248407757982"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" type="text/css" href="/css/reset.css" />
	<link rel="stylesheet" type="text/css" href="/css/site.css" />
	<link rel="stylesheet" type="text/css" href="/css/plugins.css" />
	<script type="text/javascript">
	var BASE = '';
	</script>
	
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/swfobject/2.2/swfobject.js"></script>
	<script type="text/javascript" src="/js/jquery.fancybox-1.3.1.pack.js"></script>
	<script type="text/javascript" src="/js/jquery.jalert.packed.js"></script>
	<script type="text/javascript" src="/js/util.js"></script>
	<script type="text/javascript" src="/js/site.js"></script>
<link href="http://www.afterfest.com.br/favicon.ico" type="icon" rel="icon" /><link href="http://www.afterfest.com.br/favicon.ico" type="icon" rel="shortcut icon" />	
	
</head>
<body>

<div id="topo">
	<h1><a href="/">Afterfest</a></h1>

	<div class="ads">
    			<div id="banner_flash_topo"></div>
		<script type="text/javascript">
		swfobject.embedSWF(
			'/uploads/banners/topo/20120819-052526-.swf',
			'banner_flash_topo',
			600, 
			100,
			'9.0.0',null, null, { wmode: 'transparent' })
		</script>
			</div>
</div><ul id="menu">
	<li class="item">
				<a class="baladas" href="/baladas">baladas</a>
			</li><li class="item">
				<a class="bares" href="/bares">bares</a>
			</li><li class="item">
				<a class="noticias" href="/noticias">noticias</a>
			</li><li class="item">
				<a class="coberturas " href="/coberturas ">coberturas</a>
			</li><li class="item">
				<a class="agenda" href="/agenda">agenda</a>
			</li><li class="item">
				<a class="gatas" href="/gatas">gatas</a>
			</li><li class="item">
				<a class="contato" href="/contato">contatos</a>
			</li><li class="item">
				<a class="cadastro" href="/cadastro">equipe</a>
			</li></ul>
<div class="conteudo" id="galeria">
	<div class="limitador">
		
	<div class="header_pagina">
		<div class="in">
			<strong class="header_cobertura">Coberturas</strong>
			<ul>
				<li><a href="/fotos/hd/XV-Edicao/BIXURRASCO-">ver em 3D</a></li>
			</ul>
		</div>
	</div>
	
	<div class="filtro">
		<label for="filtroLocal">LOCAL</label>			
		<select name="data[filtroLocal]" onchange="AF.buscarCoberturasPorLocal(this.value, &quot;#filtroCobertura&quot;);" id="filtroLocal">
<option value="0">TODOS</option>
<option value="10">Arabica&#039;s</option>
<option value="16">Dunluce Irish Pub</option>
<option value="62">Budapeste Dinner</option>
<option value="19">Gengibre Lounge</option>
<option value="1">180° Ubatuba</option>
<option value="60">Store Disco</option>
<option value="20">Terraço Daslu</option>
<option value="29">Opium  São Paulo</option>
<option value="31">Sirena</option>
<option value="32">Glass Club</option>
<option value="17">Parque da Cidade</option>
</select>		
		<label for="filtroCobertura">FESTA</label>			
		<select name="data[filtroCobertura]" onchange="AF.carregarCobertura(this.value);" id="filtroCobertura">
<option value="0">Escolha uma festa</option>
<option value="Loft-Club-Mogi-Inauguracao-VIP">10/04/10 - Inauguração Vip</option>
<option value="BRED-E-BRENO-Lancamento-do-novo-DVD">12/08/11 - BRED E BRENO - Lançamento do novo DVD</option>
<option value="Churas-Triplo-C">31/08/13 - Churras</option>
<option value="Festa-a-Fantasia">21/05/11 - Festa a Fantasia</option>
<option value="Friends-on-Decks-Dai-Ferreira">20/05/11 - Friends on Decks - Dai Ferreira</option>
<option value="Loft-Club-Mogi-Inauguracao">17/04/10 - Inauguração</option>
<option value="Inauguracao-Led-Club">22/06/11 - Inauguração Led Club</option>
<option value="Just-Black-DJ-Ricardo-Menga-Robotron-63">16/04/11 - Just Black - DJ Ricardo Menga + Robotron 63</option>
<option value="KF-Hip-House-Especial-1-Ano-DJ-Puff-DJ-Milk-DJ-Hadji">19/06/13 - KF Hip House - Especial 1 Ano + B.Day Gisele Fernandes - DJ Puff + DJ Milk + DJ Hadji</option>
<option value="Lancamento-Glamour-La-Locomotive-Winter-Dj-Fadi-Alameddine">17/05/13 - Lançamento Glamour + La Locomotive Winter - Dj Fadi Alameddine</option>
<option value="Only-Vip-Dj-Rubens-Junior">22/07/11 - Only Vip - Dj Rubens Junior</option>
<option value="Ticon-Live-Pistinha-Dj-Felix">27/05/11 - Ticon Live + Pistinha Dj Felix</option>
<option value="Tribe-10-Anos">16/07/11 - Tribe 10 Anos</option>
<option value="[-Sexta-Premium-]-Caio-e-Rafael-Andre-Mello-e-Diego">20/05/11 - [ Sexta Premium ]  - Caio e Rafael + Andre Mello e Diego</option>
<option value="Coquetel-de-Inauguracao">15/06/11 - Coquetel de Inauguração</option>
<option value="Loft-Club-Mogi-Dj-Edgard-Fontes">24/04/10 - Dj Edgard Fontes (Anzu)</option>
<option value="Dj-Sound-Tour-2011">21/05/11 - Dj Sound Tour 2011</option>
<option value="House-of-Stage">09/04/11 - House of Stage</option>
<option value="KF-Hip-House-34-Dj-Puff">17/07/13 - KF Hip House #34 - Dj Puff</option>
<option value="Lagbeat-1-Edicao">15/10/11 - Lagbeat 1ª Edição</option>
<option value="Michel-Palazzo-Ressaca-de-carnaval">12/03/11 - Michel Palazzo - Ressaca de carnaval</option>
<option value="Sirena-Tour">23/07/11 - Sirena Tour</option>
<option value="Sirena-Tour-Vale-Edition">14/05/11 - Sirena Tour Vale Edition</option>
<option value="Spyzer-Live">20/05/11 - Spyzer Live</option>
<option value="Festa-do-Branco-Rodrigo-Faal">30/04/11 - Festa do Branco - Rodrigo Faal</option>
<option value="House-no-Deck-Elas-Convidam-Dj-Dai-Ferreira-BDay-Livia-Krom">28/09/12 - House no Deck - Elas Convidam - Dj Daï Ferreira + B.Day Lívia Krom</option>
<option value="Sirena-Sao-Paulo-Party">20/08/11 - Sirena - São Paulo Party</option>
<option value="Tom-Keller">29/07/11 - Tom Keller</option>
<option value="Top-5-Djs-Nova-Geracao">14/05/11 - Top 5 Djs - Nova Geração</option>
<option value="Veuve-Clicquot">24/09/11 - Veuve Clicquot</option>
<option value="Aniversario-do-PUB-RAIMUNDOS">05/09/13 - Aniversário do PUB - RAIMUNDOS</option>
<option value="SEXTA-FEIRA">06/09/13 - SEXTA-FEIRA</option>
<option value="Camaleao-Festa-8-Anos-Hotnight">30/04/10 - Festa de 8 Anos Site Hotnight</option>
<option value="Festa-Fantasia">28/05/11 - Festa Fantasia</option>
<option value="Gabe-Live">18/03/11 - Gabe Live!</option>
<option value="Torcida-Dunlace-Irish-Pub-Brasil-Costa-do-Marfim">20/06/10 - Jogo: Brasil x Costa do Marfim</option>
<option value="Loft-Club-Mogi-Lançamento-Chandon-Baby-Disco-Rosé">29/05/10 - Lançamento Chandon Baby Disco Rosé</option>
<option value="Loft-Club-Mogi-Just-Black">22/05/10 - Just Black (Festa do Preto)</option>
<option value="Dj-Mark-Fischer-Winter-Vibe">05/06/10 - Dj Mark Fischer - Winter Vibe</option>
<option value="House-no-Deck-1309-Sexta-Feira">13/09/13 - House no Deck - 13.09 - Sexta-Feira</option>
<option value="XV-Edicao" selected="selected">14/09/13 - XV Edicao - FATEC</option>
<option value="Nud-Cabaret-Miami-Sessions-DJ-Rod-B.-e-DJ-Lance-Blaise">18/06/10 - Miami Sessions - DJ Rod B. e DJ Lance Blaise</option>
<option value="Natal-na-Mansao">25/12/10 - Natal na Mansão</option>
<option value="Chopperia-Loucos-Por-Futebol-Sextaneja-Robson-Luiz-e-Banda">09/08/13 - Chopperia Loucos Por Futebol - Sextaneja - Robson Luiz e Banda</option>
<option value="Loft-Club-Mogi-Energia-na-Loft">19/06/10 - Energia na Loft</option>
<option value="Felguk-Live">17/05/13 - Felguk Live!</option>
<option value="House-no-Deck-Special-BDay-Diego-Kawasaki">30/08/13 - House no Deck - Special B.Day Diego Kawasaki</option>
<option value="KF-Hip-House-36-Dj-Hadji">31/07/13 - KF Hip House #36 - Dj Hadji</option>
<option value="1-Arraia-do-PUB-Dj-Danilo-Stellet-Dj-Fabricio-Miotto-Dj-Nogue-Dj-Estevao-Manfiolli">30/06/13 - 1º Arraiá do PUB - Dj Danilo Stellet + Dj Fabrício Miotto + Dj Nogue + Dj Estevão Manfiolli</option>
<option value="Carnaval-KF-Night-Marketing-SEXTA">08/02/13 - Carnaval KF Night Marketing SEXTA</option>
<option value="Churras-da-Galera-Edicao-3-Anos">24/08/13 - Churras da Galera - Edição 3 Anos</option>
<option value="Ciroc-Party-Dj-Junior-Fonseca">07/06/13 - Ciroc Party - Dj Junior Fonseca</option>
<option value="Eclatt-Housevalley-D-NOX-Du-Serena-Tom-Keller-Andre-Pulse">17/12/11 - Eclatt Housevalley - D-NOX + Du Serena + Tom Keller + André Pulse</option>
<option value="Eco-Private">03/06/12 - Eco Private</option>
<option value="Festa-de-Abertura-Temporada-2011-2012">03/09/11 - Festa de Abertura Temporada 2011/2012</option>
<option value="Grupo-Intimidade-SA-Final-Recopa-Corinthians-x-Sao-Paulo">17/07/13 - Grupo Intimidade S/A - Final Recopa - Corinthians x São Paulo</option>
<option value="House-no-Deck-Dj-Felipe-Faria-Dj-Noggue">09/08/13 - House no Deck - Dj Felipe Faria + Dj Noggue</option>
<option value="House-no-Deck-Dj-Paul-C-e-DJ-Oca">20/07/12 - House no Deck - Dj Paul C e DJ Oca</option>
<option value="House-no-Deck-Santo-Luxo-Dj-Pedro-Saab">23/08/13 - House no Deck - Santo Luxo - Dj Pedro Saab</option>
<option value="House-no-Deck-Especial-Afterfest-6-Projeto-Bassline-Andrew-Thompson">09/11/12 - House no Deck Especial Afterfest #6 - Projeto Bassline + Andrew Thompson</option>
<option value="KF-Hip-House-10-Dj-Puff-BDay-Jessica-Caroline">17/10/12 - KF Hip House #10 - Dj Puff + B.Day Jessica Caroline</option>
<option value="KF-Hip-House-28-DJ-Hadji-Anao-Live-vocal">29/05/13 - KF Hip House #28 - DJ Hadji + Anão (Live vocal)</option>
<option value="KF-Hip-House-32-DJ-Puff">26/06/13 - KF Hip House #32 - DJ Puff</option>
<option value="KF-Hip-House-37-DJ-Puff">07/08/13 - KF Hip House #37 - DJ Puff</option>
<option value="KF-Hip-House-Volcom-Dark-Bar-World-Tour-Dj-Puff">27/08/13 - KF Hip House - Volcom Dark Bar World Tour - Dj Puff</option>
<option value="Pagodao-do-Santo-Cupim-na-Mesa-Andre-Marinho-SP-Grupo-DIVA-Tudo-Entre-Amigos-Sambaja">25/05/13 - Pagodão do Santo - Cupim na Mesa (André Marinho - SP) + Grupo DIVA + Tudo Entre Amigos + Sambajá</option>
<option value="Pagodao-do-Santo-Cupim-na-Mesa-GPC-Batucada-E-Stefano-e-Grupo-Delirio">13/04/13 - Pagodão do Santo - Cupim na Mesa + GPC + Batucada E Stéfano e Grupo Delírio</option>
<option value="Ultra-Music-Festival-Brasil-Swedish-House-Mafia">03/12/11 - Ultra Music Festival - Brasil - Swedish House Mafia</option>
<option value="[-Sexta-Premium-]-Marcos-Gustavo-Diego-Carvalho-Andre">19/08/11 - [ Sexta Premium ] - Marcos &amp; Gustavo + Diego Carvalho &amp; André</option>
<option value="Camaleao-Jogo-Brasil-x-Chile">28/06/10 - Jogo: Brasil x Chile</option>
<option value="Pagodao-Do-Santo-Cupim-na-Mesa-Grupo-Pode-Confiar-Stefano-e-Grupo-Delirio-Grupo-Batucada-Dj-Estevao-Manfiolli">06/07/13 - Pagodão Do Santo - Cupim na Mesa + Grupo Pode Confiar + Stéfano e Grupo Delírio + Grupo Batucada + Dj Estevão Manfiolli</option>
<option value="Camaleao-Festa-de-1-Ano">02/07/10 - Festa de 1 Ano da Camaleão</option>
<option value="Fapija-2010-Show-Maria-Cecília-e-Rodolfo">10/07/10 - Camarote Show Maria Cecília e Rodolfo</option>
<option value="Festa-do-Branco---DEEP-Entertainment---Terraco-Daslu">28/08/10 - Festa do Branco - DEEP Entertainment - Terraço Daslu</option>
<option value="Loft-Club-Mogi-Seven-7-Pecados-Capitais">10/07/10 - Seven - 7 Pecados Capitais</option>
<option value="Fapija-2010-Thai-Estacao-Show-Maria-Cecília-e-Rodolfo">10/07/10 - Estação Show</option>
<option value="Inauguracao">04/09/10 - Inauguração - Maresias-SP</option>
<option value="Martijn-Ten-Velden">29/01/11 - Martijn Ten Velden</option>
<option value="Violive">03/09/10 - Violive</option>
<option value="We-Love-Electro-2-Anos">12/02/11 - We Love Electro - 2 Anos</option>
<option value="ElectroFolia---Dj-Dimy-Soler">31/07/10 - ElectroFolia - Dj Dimy Soler</option>
<option value="MOB-Gathering">02/10/10 - MOB Gathering - Hotel Transamérica SP</option>
<option value="Chopperia-Loucos-Por-Futebol-Sextaneja-David-Saconi">26/07/13 - Chopperia Loucos Por Futebol - Sextaneja - David Saconi</option>
<option value="Circo-Loco-The-Next-Level-Dj-Peppo-Santiago-Dj-Rodrigo-S-Legiao-Urbana-Cover">24/05/13 - Circo Loco - The Next Level - Dj Peppo Santiago + Dj Rodrigo S. + Legião Urbana Cover</option>
<option value="Desfile-OFD-10-Anos">23/09/10 - Desfile OFD 10 Anos [ Famosos ]</option>
<option value="Festa-do-Branco-ZOOM-BOXX">14/12/12 - Festa do Branco - ZOOM BOXX</option>
<option value="House-no-Deck-Encerramento-Fire-Up-Dj-Juy">02/08/13 - House no Deck - Encerramento Fire Up - Dj Juy</option>
<option value="House-no-Deck-Warm-Up-Parador-Maresias-DJ-Marcelo-Tromboni">05/10/12 - House no Deck - Warm Up Parador Maresias - DJ Marcelo Tromboni</option>
<option value="House-Valley-Winter-Edition-Dj-Carka-Schwiderski-Dj-Juy-Dj-Robson-Nogueira-Dj-Thiago-Germek-Dj-Pedro-Saab">06/07/13 - House Valley Winter Edition - Dj Carla Schwiderski + Dj Juy + Dj Robson Nogueira + Dj  Thiago Germek + Dj Pedro Saab</option>
<option value="KF-Hip-House-11-Dj-Hadji">24/10/12 - KF Hip House #11 - Dj Hadji</option>
<option value="KF-Hip-House-29-DJ-Puff">05/06/13 - KF Hip House #29 - DJ Puff</option>
<option value="Oscar-Fashion-Days">22/09/10 - Oscar Fashion Days 10 Anos</option>
<option value="Pagodao-Do-Santo-com-Cupim-na-Mesa-Intimidade-S-A-Pode-Confiar-Stefano-Dj-Estevao-Manfiolli">15/06/13 - Pagodão Do Santo com Cupim na Mesa + Intimidade S-A + Pode Confiar + Stéfano + Dj Estevão Manfiolli</option>
<option value="Celebration-BDay-Dj-Paul-C-Noggue-Nicodemo">26/07/13 - Celebration B.Day - Dj Paul C. + Noggue + Nicodemo</option>
<option value="Choperia-Loucos-Por-Futebol-Grupo-Pagode-Sapeca">21/07/13 - Chopperia Loucos Por Futebol - Grupo Pagode Sapeca</option>
<option value="Festa-de-1-Ano-da-PROMO">09/10/10 - Festa de 1 Ano da PROMO</option>
<option value="Glamour-by-Fadi-Alameddine">09/03/13 - Glamour by Fadi Alameddine</option>
<option value="Hedkandi-11-Years-Party-Dj-Sebastian-Arevalo-Dj-Thiago-Germek-Dj-Estevao-Manfiolli-Dj-Danilo-Stellet-Dj-Fabricio-Mioto-Dj-Pedro-Saab">20/07/13 - Hedkandi 11 Years Party - Dj Sebastian Arévalo + Dj Thiago Germek + Dj Estevão Manfiolli + Dj Danilo Stellet + Dj Fabricio Mioto + Dj Pedro Saab</option>
<option value="House-no-Deck-FUCK-YOU-PLASTIC-DJ-Bassline-Andrew-Thompson-Rose-Aloy-vs-Marcelo-Nascimento-Marcelo-Lifeguard-vs-Diego-Kaos">16/08/13 - House no Deck - !FUCK YOU PLASTIC DJ! - Bassline + Andrew Thompson + Rose Aloy vs Marcelo Nascimento + Marcelo Lifeguard vs Diego Kaos</option>
<option value="House-no-Deck-Dj-Marcelo-Tromboni-2">19/07/13 - House no Deck - Dj Marcelo Tromboni #2</option>
<option value="KF-Hip-House-23-DJ-Milk">24/04/13 - KF Hip House #23 - DJ Milk - B.Day Lucas Funchal</option>
<option value="KF-Hip-House-35-DJ-Milk">24/07/13 - KF Hip House #35 - DJ Milk</option>
<option value="Reabertura">28/08/13 - Reabertura</option>
<option value="Saint-Patrick's-Day-Dj-Estevao-Manfiolli">17/03/13 - Saint Patrick&#039;s Day - Dj Estevão Manfiolli</option>
<option value="AfterFest-6-Anos-com-DJ-Felix-e-Renan-Noise-BDay-Suellen-Thiago-Luiz">14/09/12 - AfterFest 6 Anos com DJ Felix e Renan Noise + B.Day Suellen + Thiago + Luiz</option>
<option value="Bruno-Barudi-e-DarthVader">26/12/11 - Bruno Barudi e Darth&amp;Vader</option>
<option value="Ciroc-Party">15/03/13 - Cîroc Party</option>
<option value="DJ-Mario-Fischetti-Dj-Danilo-Stellet">31/08/12 - DJ Mario Fischetti + Dj Danilo Stellet</option>
<option value="Dream-Session-Dj-Andre-Plati">15/03/13 - Dream Session - Dj André Plati</option>
<option value="House-no-Deck-FUCK-YOU-PLASTIC-DJ-Dj-Andrew-Thompson-Dj-Marcelo-Lifeguard-e-Dj-Diego-Kaos">05/07/13 - House no Deck - !FUCK YOU PLASTIC DJ! - Dj  Andrew Thompson + Dj Marcelo Lifeguard e Dj Diego Kaos</option>
<option value="KF-Hip-House-26-DJ-King">15/05/13 - KF Hip House #26 - DJ King</option>
<option value="KF-Hip-House-27-DJ-Milk">22/05/13 - KF Hip House #27 - DJ Milk + B.Day Monique Bertolini</option>
<option value="KF-Hip-House-3-Dj-Milk">22/08/12 - KF Hip House #3 - Dj Milk</option>
<option value="KF-Hip-House-5-Dj-Hadji-Mc-Anao">05/09/12 - KF Hip House #5 - Dj Hadji + Mc Anão</option>
<option value="One-Year-Led---White-Party">05/11/10 - One Year Led - White Party</option>
<option value="Quarta-e-Quinta">29/08/12 - Quarta e Quinta</option>
<option value="Rodizio-de-Quarta">01/08/12 - Rodízio de Quarta</option>
<option value="Rodizio-dos-Amigos-7">17/10/12 - Rodízio dos Amigos #7</option>
<option value="Rodizio-dos-Amigos-8">07/11/12 - Rodízio dos Amigos #8</option>
<option value="Sirena-Tour-Sao-Jose-dos-Campos-2013-Pedro-Saab-Bassline-Southmen-Tom-Keller-Press-Kit">11/05/13 - Sirena Tour São José dos Campos 2013 - Pedro Saab + Bassline + Southmen + Tom Keller + Press Kit</option>
<option value="TRIBE-50-Edicao">07/07/12 - TRIBE - 50ª Edição - por Higor Bono e Walter Henrique</option>
<option value="Warm-up-Sirena-Tour-Dj-Dai-Ferreira-BDay-Bruna-Marcio-Dantas">03/05/13 - Warm-up Sirena Tour - Dj Däi Ferreira B.Day Bruna + Marcio Dantas</option>
<option value="Yazigi-apresenta-Halloween-no-PUB-Dj-Milk">31/10/12 - Yázigi apresenta Halloween no PUB - Dj Milk</option>
<option value="IM-Fest">30/10/10 - IM Fest</option>
<option value="OCTOBERPUB">24/10/10 - OCTOBERPUB</option>
<option value="After-House-Sessions-1-Edicao">04/12/11 - After House Sessions - 1º Edição</option>
<option value="Eclatt-6-anos---White-Party">06/11/10 - Eclatt 6 anos - White Party</option>
<option value="Opium-Sao-Paulo-Inauguracao">10/11/10 - Inauguração</option>
<option value="Rodizio-dos-Amigos-6">10/10/12 - Rodízio dos Amigos #6</option>
<option value="Victor-Ruiz-Any-Mello">22/02/13 - Victor Ruiz &amp; Any Mello</option>
<option value="Drods-5-Anos">13/11/10 - Drods 5 Anos</option>
<option value="Festa-da-Grife-Forum">19/11/10 - Festa da Grife Forum</option>
<option value="Glam-Friday">29/10/10 - Glam Friday</option>
<option value="IM-Fest---Electrixx">04/12/10 - IM Fest - Electrixx</option>
<option value="Reason">23/11/10 - Reason</option>
<option value="Hot-Hot---Dj-Mandraks-Le-paladino-e-Gui-Rozelli">18/12/10 - Hot Hot - Dj Mandraks, Le paladino e Gui Rozelli.</option>
<option value="D-nox--Beckers">29/12/10 - D-nox &amp; Beckers - Perfect Life</option>
<option value="Sirena-Tour-Mogi-das-Cruzes">04/08/12 - Sirena Tour Mogi das Cruzes</option>
<option value="Tequila-Night---Simone-Pellizari">17/12/10 - Tequila Night - Simone Pellizari</option>
<option value="Water-Republic-Anniversary-2010-">18/12/10 - Water Republic Anniversary 2010 </option>
<option value="Choperia-Loucos-Por-Futebol-Academia-F4-Fitness-Dj-Cristiane-selecao-">03/08/13 - Choperia Loucos Por Futebol - Academia F4 Fitness - Dj Cristiane (seleção) </option>
<option value="Choperia-Loucos-Por-Futebol-Sextaneja-2-David-Saconi">02/08/13 - Choperia Loucos Por Futebol - Sextaneja #2 - David Saconi</option>
<option value="Deep-Aires-Sunset-Hat-Party">01/05/13 - Deep Aires - Sunset Hat Party</option>
<option value="Dunluce-Connect-Gold-Label-Reserve-Dj-Juy">29/06/13 - Dunluce Connect - Gold Label Reserve - Dj Juy</option>
<option value="House-no-Deck-Press-KIT-Sirena-">24/08/12 - House no Deck - Press KIT - Sirena </option>
<option value="Inauguracao-VIP">15/01/11 - Inauguração-VIP</option>
<option value="KF-Hip-House-22-DJ-Hadji">17/04/13 - KF Hip House #22 - DJ Hadji</option>
<option value="KF-Hip-House-24-DJ-Milk-KL-Jay">01/05/13 - KF Hip House #24 - DJ Milk + KL Jay</option>
<option value="KF-Hip-House-25-DJ-Hadji">08/05/13 - KF Hip House #25 - DJ Hadji</option>
<option value="KF-Hip-House-30-Festa-dos-Solteiros-Dj-Milk">12/06/13 - KF Hip House #30 - Festa dos Solteiros - Dj Milk</option>
<option value="B-Day-Dalton-Duarte-Dj-Carlinhos-Silva-mendigo-Marcelo-Tromboni-e-Edu-Poppo">30/06/12 - B-Day Dalton Duarte - Dj Carlinhos Silva (mendigo), Marcelo Tromboni e Edu Poppo</option>
<option value="Ballrange-Party-Special-BDay-Danilo-Stellet-Dj-Fabricio-Miotto-Noggue">18/05/13 - Ballrange Party - Special B.Day Danilo Stellet + Dj Fabricio Miotto + Noggue</option>
<option value="Bassline">16/02/13 - Bassline</option>
<option value="Carnaval-KF-Night-Marketing-TERCA">12/02/13 - Carnaval KF Night Marketing TERÇA</option>
<option value="Circus-Folia-Rodrigo-Santafe-BDay-Renato-Natali-e-Claudia-Macedo">01/02/13 - Circus Folia - Rodrigo &amp; Santafé - B.Day - Renato Natali e Claudia Macedo</option>
<option value="Comemoracao-4-Anos">17/07/13 - Comemoração 4 Anos</option>
<option value="DJ-Naccarati-Dj-Marcelo-Tromboni">01/11/12 - DJ Naccarati + Dj Marcelo Tromboni</option>
<option value="Eclatt-007-Female-Angels">13/08/11 - Eclatt 007 - Female Angels</option>
<option value="Festa-do-Branco-2011-DEEP-Entertainment-Terraco-Daslu">06/09/11 - Festa do Branco 2011 - DEEP Entertainment - Terraço Daslu</option>
<option value="House-no-Deck-Dj-Bruno-Mendez">21/09/12 - House no Deck - Dj Bruno Mendez</option>
<option value="House-no-Deck-Dj-Juy-Dj-Kleber-Alves-BDay-Dalton-Duarte-Ana-Claudia-Carvalho-Gerson-Dias">14/06/13 - House no Deck - Dj Juy + Dj Kleber Alves - B.Day Dalton Duarte + Ana Cláudia Carvalho + Gerson Dias</option>
<option value="House-no-Deck-Especial-Dia-das-Mulheres-Angel-Sun-BDay-Luiz-Gustavo">08/03/13 - House no Deck - Especial Dia das Mulheres - Angel Sun - B.Day Luiz Gustavo</option>
<option value="House-no-Deck-Warm-up-Eclatt-8-Anos">14/12/12 - House no Deck - Warm-up Eclatt 8 Anos - B.Day Grace Kelly</option>
<option value="Inauguracao-Glass-Club">22/01/11 - Inauguração Glass Club</option>
<option value="Jantar-a-la-carte">05/10/12 - Jantar a la carte</option>
<option value="Ketel-One-Cocktail's-Day">24/05/13 - Ketel One Cocktail&#039;s Day - Special B.Day Dj Carl + Kleber Alves</option>
<option value="KF-Hip-House-13-Dj-Milk">12/12/12 - KF Hip House #13 - Dj Milk</option>
<option value="KF-Hip-House-16-Dj-Milk">23/01/13 - KF Hip House #16 - Dj Milk - B.Day Bianca Rabelo =D</option>
<option value="KF-Hip-House-18-DJ-KL-Jay-DJ-Hadji">06/03/13 - KF Hip House #18 - DJ KL Jay + DJ Hadji</option>
<option value="KF-Hip-House-19-DJ-Puff">13/03/13 - KF Hip House #19 - DJ Puff</option>
<option value="KF-Hip-House-2-Dj-Hadji">15/08/12 - KF Hip House #2 -  Dj Hadji</option>
<option value="KF-Hip-House-21-DJ-CIA-DJ-Milk">10/04/13 - KF Hip House #21 - DJ CIA + DJ Milk</option>
<option value="KF-Hip-House-4-Dj-Puff">29/08/12 - KF Hip House #4 - Dj Puff</option>
<option value="Parktronic">24/07/11 - Parktronic 2011</option>
<option value="Pre-Carnaval-Pub-Folia">27/01/13 - Pré Carnaval Pub Folia</option>
<option value="Quarta-dos-Amigos-10">19/12/12 - Quarta dos Amigos #10</option>
<option value="Quarta-dos-Amigos-12">05/03/13 - Quarta dos Amigos #12</option>
<option value="Quarta-dos-Amigos-9">12/12/12 - Quarta dos Amigos #9</option>
<option value="Reinauguracao">15/02/13 - Reinauguração</option>
<option value="Spring-Summer">23/09/12 - Spring Summer</option>
<option value="Warm-up-Electrance-6-Anos-">20/08/11 - Warm-up Electrance 6 Anos </option>
<option value="Welcome-Party-Dj-Andre-Marchezini-BDay-Aline-Zito">26/04/13 - Welcome Party - Dj André Marchezini + B.Day Aline Zito</option>
<option value="18-Anos-D-Nox-Beckers-Erick-Morillo">13/11/11 - 18 Anos D-Nox &amp; Beckers + Erick Morillo</option>
<option value="Deep-Aires-Dj-Andre-Marchezini">17/04/13 - Deep Aires - Dj Andre Marchezini</option>
<option value="Friday-Connect-Dj-Nuts-Noise">29/03/13 - Friday Connect - Dj Nuts Noise</option>
<option value="House-no-Deck-Bassline-Edu-Reis-BDay-Walter-Henrique-e-Felix">19/04/13 - House no Deck - Bassline + Edu Reis - B.Day Walter Henrique e Felix</option>
<option value="House-no-Deck-Noggue-Marco-Aoki">22/02/13 - House no Deck - Noggue + Marco Aoki</option>
<option value="Housevalley-Dj-Vee-Brondi-Edu-Zottini-Bassline-Juy-Pedro-Saab">20/04/13 - Housevalley - Dj Vee Brondi + Edu Zottini + Bassline + Juy + Pedro Saab</option>
<option value="KF-Hip-House-20-DJ-Hadji-Anao-live-vocal">27/03/13 - KF Hip House #20 - DJ Hadji + Anão (live vocal)</option>
<option value="Lancamento-Hedkandi-BDay-Allan-Mello-Dj-Rubens-Jr">28/06/13 - Lançamento Hedkandi + B.Day Allan Mello - Dj Rubens Jr.</option>
<option value="Markus-Binapfl">04/02/11 - Markus Binapfl</option>
<option value="Molhe-On-The-Road-Evento-Exclusivo-no-Brasil-DJ-DEXTRO-MC-KATORZ">21/10/11 - Molhe On The Road - Evento Exclusivo no Brasil - DJ DEXTRO + MC KATORZ</option>
<option value="Raul-Boesel">13/08/11 - Raul Boesel</option>
<option value="AfterFest-Party-7">22/03/13 - AfterFest Party #7 + B.Day Tatiana Andrade</option>
<option value="DEXTERZ">30/04/11 - DEXTERZ</option>
<option value="DJ-Tubarao">08/07/11 - DJ Tubarão</option>
<option value="Electrance-6-Anos">27/08/11 - Electrance 6 Anos</option>
<option value="House-no-Deck-1-Ano-Parceria-Daltinho-Kengao-DJ-Felix">30/11/12 - House no Deck - 1 Ano - Parceria Daltinho + Kengão - DJ Felix</option>
<option value="House-no-Deck-AfterFest-5-Edicao">27/07/12 - House no Deck - AfterFest 5ª Edição</option>
<option value="House-no-Deck-Niver-Pamela-Rodrigues-Dj-Robson-Nogueira">17/08/12 - House no Deck - Niver Pâmela Rodrigues + Dj Robson Nogueira</option>
<option value="House-no-Deck-Phyton-DJ-Oca-">26/10/12 - House no Deck - Phyton - DJ Oca </option>
<option value="House-no-Deck-TOP-DJ-Nuts-Noise-Banda-Arena-Rock">13/07/12 - House no Deck - TOP DJ Nuts Noise + Banda Arena Rock</option>
<option value="KF-Hip-House-39-Dj-Hadji">21/08/13 - KF Hip House #39 - Dj Hadji</option>
<option value="LUMIERE-Ressaca-de-Carnaval">12/03/11 - LUMIÉRE - Ressaca de Carnaval</option>
<option value="Quarta-dos-Amigos-11">27/02/13 - Quarta dos Amigos #11</option>
<option value="Rafael-Noronha">19/03/11 - Rafael Noronha</option>
<option value="Rodizio-de-Quarta-2">05/09/12 - Rodízio de Quarta #2</option>
<option value="Rodizio-de-Quarta-15-08">15/08/12 - Rodízio de Quarta - 15/08</option>
<option value="Xurras4Friends-Plinio-Guizera-e-Tail">06/11/11 - Xurras4Friends - Plínio, Guizera e Tail</option>
<option value="Dj-Vitor-Lima">05/02/11 - Dj Vitor Lima</option>
<option value="Just-White-Dj-Edgard-Fontes-Remix">12/02/11 - Just White - Dj Edgard Fontes (Remix)</option>
<option value="Temporada-2011-DJ-Mayara-Leme">28/01/11 - Abertura Temporada 2011 - DJ Mayara Leme</option>
<option value="Electrance-2011">21/05/11 - Electrance 2011</option>
<option value="Sharp-Bend-Ricardo-Menga">27/08/11 - Sharp Bend + Ricardo Menga</option>
<option value="Aniversario-7-Anos-PUB">15/09/12 - Aniversário 7 Anos PUB</option>
<option value="Camarote-AfterFest-4-Anos-Dj-Felix-Dj-Rick-DUB">14/10/11 - Camarote AfterFest  4 Anos + Dj Felix + Dj Rick DUB</option>
<option value="Eclatt-Only-White-Eletrixx-Thricie">08/10/11 - Eclatt Only White - Eletrixx + Thricie</option>
<option value="Fabio-Castro-Clube-das-Mulheres">09/07/11 - Fabio Castro</option>
<option value="House-no-Deck-DJ-Gelipe-Faria-DJ-Jr-Fonseca-Encerramento-Fire-UP">03/08/12 - House no Deck -  DJ Felipe Faria + DJ Jr. Fonseca - Encerramento Fire UP</option>
<option value="House-no-Deck-Dj-Felix-Robson-Nogueira">31/08/12 - House no Deck -Dj Felix + Robson Nogueira</option>
<option value="Imagine-Dj-Davison-Lemos">04/11/11 - Imagine - Dj Davison Lemos</option>
<option value="Just-Black-DJ-Viktor-Mora">04/11/11 - Just Black - DJ Viktor Mora</option>
<option value="KF-Hip-House-12-Dj-Hadji">07/11/12 - KF Hip House #12 - Dj Hadji</option>
<option value="KF-Hip-House-17-Negrali-DJ-Nene-DJ-Puff">20/02/13 - KF Hip House #17 - Negrali + DJ Nenê + DJ Puff</option>
<option value="KF-Hip-House-18-Dj-Milk-Groove-it">27/02/13 - KF Hip House #18 - Dj Milk + Groove It</option>
<option value="Marcelo-Sa-Pistinha-After-Renan-Noise">07/05/11 - Marcelo Sá, Pistinha After Renan Noise</option>
<option value="Rodizio-de-Quarta-3">26/09/12 - Rodízio de Quarta #3</option>
<option value="Super-Buddies-Thiago-Marques-Cassiano-E-Juliano-Urizzi-BDay-Felipe-Tavares-e-Joao-Marcelo-Andery">30/09/11 - Super Buddies - Thiago Marques, Cassiano E Juliano Urizzi B.Day Felipe Tavares e João Marcelo Andery</option>
<option value="TRIBALTECH-2012-The-End">29/09/12 - TRIBALTECH 2012 - The End - Fotógrafo: Higor Bono</option>
<option value="Warm-up-TRIBE-CLUB-Du-Serena-x-Dahan-Juy-Bassline">19/01/13 - Warm-up TRIBE CLUB - Du Serena x Dahan + Juy + Bassline</option>
<option value="[-Sexta-Premium-]-Raphael-Leandro-Bruno-Ray">26/08/11 - [ Sexta Premium ] - Raphael Leandro + Bruno &amp; Ray</option>
<option value="AfterFest-4-Anos-DJ-Feio-Felix-Rodrigo-S-e-Renan-Noise">21/10/11 - AfterFest 4 Anos - DJ Feio, Felix, Rodrigo S. e Renan Noise</option>
<option value="CABARET-|-O-Melhor-do-Funk-Carioca">07/10/11 - CABARET | O Melhor do Funk Carioca</option>
<option value="Electrixx">22/03/13 - Electrixx</option>
<option value="House-4-Friends-1">09/09/11 - House 4 Friends #1</option>
<option value="House-no-Deck-Dj-Du-Aoki-Dj-Dirceu-Pires">10/08/12 - House no Deck - Dj Du Aoki + Dj Dirceu Pires</option>
<option value="KF-Hip-House-39-Dj-Milk">14/08/13 - KF Hip House #39 - Dj Milk</option>
<option value="SPYZER">25/11/11 - SPYZER</option>
<option value="Top-Secret-2-Edicao">01/10/11 - Top Secret - 2ª Edição</option>
<option value="Bruno-Barudi-Dj-Magui">25/01/13 - Bruno Barudi + Dj Magui</option>
<option value="House-no-DECK">02/12/11 - House no DECK</option>
<option value="KF-Hip-House-Dj-Puff-Dj-Hadji">08/08/12 - KF Hip House #1 - Dj Puff + Dj Hadji</option>
<option value="KF-Hip-House-9-Dj-Milk-BDay-Marilia-Maria">10/10/12 - KF Hip House #9 - Dj Milk + B.Day Marília Maria</option>
<option value="PINK-|-HIP-HOP-|-HOUSE-">26/08/11 - PINK | HIP-HOP | HOUSE </option>
<option value="Energia-na-Glass">14/05/11 - Energia na Glass</option>
<option value="Coquetel-Freixenet-Dj-Rubens-Junior">01/03/13 - Coquetel Freixenet - Dj Rubens Junior - B.Day Sabrina Rabelo</option>
<option value="Festa-do-Branco-2011">08/10/11 - Festa do Branco 2011</option>
<option value="House-no-Deck-Dj-Robson-Nogueira-2">12/07/13 - House no Deck - Dj Robson Nogueira #2</option>
<option value="Rodizio-dos-Amigos-4">19/09/12 - Rodízio dos Amigos #4</option>
<option value="Felguk">08/12/12 - Felguk</option>
<option value="House-no-Deck-Dj-Robson-Nogueira-The-Hitmakers">19/10/12 - House no Deck - Dj Robson Nogueira - The Hitmakers</option>
<option value="KF-Hip-House-8-Dj-Hadji">26/09/12 - KF Hip House #8 - Dj Hadji</option>
<option value="Boris-Brejcha-Du-Serena">22/10/11 - Boris Brejcha + Du Serena</option>
<option value="Gallery-Classic-House">01/11/11 - Gallery Classic House - Fabiano Salles</option>
<option value="House-no-Deck-Warm-UP-Space-Ibiza-Campos-do-Jordao">06/07/12 - House no Deck - Warm UP Space Ibiza Campos do Jordão</option>
<option value="Island-Pool-Party">29/10/11 - Island Pool Party</option>
<option value="KF-Hip-House-7-Dj-Milk">19/09/12 - KF Hip House #7 - Dj Milk</option>
<option value="KF-Hip-House-14-Dj-Milk">19/12/12 - KF Hip House #14 - Dj Milk</option>
<option value="Gabe-Wrecked-Machines">07/01/12 - Gabe - Wrecked Machines</option>
<option value="Aniversario-do-Kengao">13/01/12 - Aniversário do Kengão</option>
<option value="Tribe-Club-Summer-Edition">21/01/12 - Tribe Club - Summer Edition</option>
<option value="La-Madre-DJ-Robson-Nogueira">27/01/12 - La Madre - DJ Robson Nogueira</option>
<option value="Summer-After">26/02/12 - Summer After</option>
<option value="Reinauguracao-Pos-Reforma">24/02/12 - Reinauguração Pós Reforma</option>
<option value="Pub-in-the-House-BDay-Sabrina-Rabelo">29/02/12 - Pub in the House + B.Day Sabrina Rabelo</option>
<option value="House-no-Deck-Dj-Nicodemo-Banda-All-Star-40">02/03/12 - House no Deck - Dj Nicodemo + Banda All Star 40</option>
<option value="House-no-Deck-Niver-Allan-Mello-Magno-Nascimento-Vanessa-Cabral">29/06/12 - House no Deck - Niver Allan Mello, Magno Nascimento, Vanessa Cabral</option>
<option value="QUARTA-FEIRA">04/09/13 - QUARTA-FEIRA</option>
<option value="House-no-Deck-com-Du-Aoki-Marco-Aoki-e-Diego-Colombini">16/03/12 - House no Deck com Du Aoki, Marco Aoki e Diego Colombini</option>
<option value="House-no-Deck-AfterFest-2a-Edicao">09/03/12 - House no Deck - AfterFest 2ª Edição + B.Day Plínio Boucault</option>
<option value="House-4-Friends-DJ-Felix-Mixer-Live">17/03/12 - House 4 Friends - DJ Felix + Mixer Live</option>
<option value="Beach-Conception-Dj-Felix-Dj-Pedro-Scarpa">24/03/12 - Beach Conception - Dj Felix + Dj Pedro Scarpa</option>
<option value="Electrance-Preview-Indoor">29/01/12 - Electrance Preview Indoor</option>
<option value="Island-Pool-Party-II">17/03/12 - Island Pool Party II</option>
<option value="House-no-Deck-com-DJ-Robson-Nogueira">23/03/12 - House no Deck com DJ Robson Nogueira</option>
<option value="House-no-Deck-Dj-Du-Aoki-Niver-Juliete-Leal">11/05/12 - House no Deck - Dj Du Aoki + Niver Juliete Leal</option>
<option value="Ministry-of-Sound-Campinas-Camarote-Perfect-Life">30/03/12 - Ministry of Sound Campinas - Camarote Perfect Life</option>
<option value="House-no-Deck-AfterFest-3-Edicao-BDay-Rick-Afterfest-Dj-Felix-e-Juliana-Minini">27/04/12 - House no Deck - AfterFest 3ª Edição + B.Day Rick Afterfest, Dj Felix e Juliana Minini</option>
<option value="House-no-Deck-Niver-Danielle-Ferri-e-Maiara-Nozari-Dj-Robson-Nogueira-Dj-Marcelo-Tromboni">18/05/12 - House no Deck - Niver Danielle Ferri e Maiara Nozari - Dj Robson Nogueira, Dj Marcelo Tromboni</option>
<option value="House-no-Deck-Warm-Up-Fire-Up-Lounge-Dj-Edu-Zottini">21/06/13 - House no Deck - Warm Up Fire Up Lounge - Dj Edu Zottini</option>
<option value="Hip-House-Guten">01/06/12 - Hip-House Guten</option>
<option value="House-No-Deck-Dj-Robson-Nogueira">01/06/12 - House No Deck - Dj Robson Nogueira</option>
</select>	</div>
	
	<div id="comum">
		<div class="info">
			<h2>
								Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013			</h2>
			<div class="compartilhar">
				<div class="addthis_toolbox addthis_pill_combo">
    <a class="addthis_button_tweet" tw:count="horizontal"></a>
    <a class="addthis_button_facebook_like"></a>
    <a class="addthis_counter addthis_pill_style"></a>
</div>

<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=afterfest"></script>			</div>
		</div>
	
		<div id="listaFotos">
					<a href="/uploads/coberturas/XV-Edicao/20130919-084632-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 1" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084632-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 1"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 1"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084632-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 2" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084632-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 2"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 2"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084632-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 3" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084632-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 3"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 3"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084632-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 4" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084632-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 4"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 4"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084632-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 5" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084632-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 5"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 5"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084632-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 6" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084632-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 6"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 6"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084632-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 7" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084632-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 7"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 7"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084632-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 8" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084632-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 8"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 8"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084632-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 9" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084632-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 9"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 9"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084632-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 10" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084632-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 10"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 10"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084632-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 11" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084632-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 11"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 11"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084632-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 12" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084632-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 12"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 12"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084632-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 13" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084632-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 13"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 13"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084632-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 14" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084632-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 14"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 14"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084632-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 15" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084632-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 15"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 15"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084632-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 16" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084632-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 16"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 16"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084713-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 17" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084713-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 17"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 17"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084713-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 18" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084713-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 18"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 18"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084713-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 19" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084713-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 19"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 19"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084713-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 20" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084713-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 20"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 20"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084713-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 21" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084713-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 21"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 21"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084713-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 22" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084713-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 22"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 22"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084713-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 23" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084713-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 23"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 23"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084713-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 24" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084713-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 24"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 24"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084713-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 25" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084713-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 25"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 25"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084713-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 26" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084713-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 26"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 26"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084713-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 27" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084713-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 27"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 27"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084713-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 28" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084713-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 28"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 28"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084713-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 29" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084713-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 29"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 29"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084713-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 30" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084713-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 30"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 30"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084713-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 31" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084713-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 31"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 31"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084713-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 32" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084713-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 32"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 32"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084752-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 33" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084752-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 33"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 33"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084752-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 34" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084752-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 34"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 34"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084752-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 35" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084752-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 35"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 35"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084752-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 36" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084752-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 36"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 36"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084752-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 37" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084752-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 37"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 37"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084752-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 38" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084752-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 38"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 38"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084752-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 39" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084752-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 39"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 39"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084752-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 40" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084752-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 40"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 40"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084752-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 41" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084752-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 41"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 41"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084752-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 42" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084752-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 42"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 42"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084752-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 43" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084752-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 43"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 43"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084752-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 44" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084752-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 44"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 44"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084752-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 45" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084752-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 45"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 45"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084752-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 46" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084752-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 46"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 46"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084752-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 47" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084752-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 47"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 47"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084752-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 48" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084752-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 48"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 48"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084834-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 49" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084834-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 49"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 49"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084834-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 50" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084834-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 50"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 50"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084834-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 51" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084834-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 51"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 51"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084834-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 52" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084834-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 52"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 52"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084834-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 53" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084834-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 53"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 53"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084834-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 54" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084834-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 54"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 54"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084834-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 55" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084834-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 55"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 55"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084834-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 56" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084834-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 56"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 56"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084834-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 57" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084834-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 57"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 57"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084834-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 58" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084834-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 58"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 58"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084834-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 59" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084834-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 59"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 59"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084834-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 60" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084834-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 60"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 60"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084834-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 61" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084834-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 61"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 61"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084834-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 62" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084834-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 62"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 62"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084834-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 63" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084834-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 63"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 63"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084834-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 64" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084834-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 64"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 64"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084938-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 65" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084938-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 65"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 65"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084938-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 66" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084938-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 66"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 66"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084938-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 67" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084938-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 67"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 67"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084938-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 68" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084938-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 68"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 68"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084938-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 69" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084938-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 69"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 69"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084938-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 70" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084938-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 70"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 70"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084938-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 71" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084938-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 71"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 71"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084938-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 72" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084938-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 72"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 72"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084938-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 73" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084938-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 73"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 73"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084938-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 74" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084938-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 74"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 74"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084938-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 75" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084938-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 75"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 75"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084938-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 76" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084938-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 76"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 76"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084938-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 77" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084938-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 77"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 77"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084938-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 78" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084938-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 78"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 78"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084938-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 79" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084938-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 79"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 79"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-084938-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 80" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-084938-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 80"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 80"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085049-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 81" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085049-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 81"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 81"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085049-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 82" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085049-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 82"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 82"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085049-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 83" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085049-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 83"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 83"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085049-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 84" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085049-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 84"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 84"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085049-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 85" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085049-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 85"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 85"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085049-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 86" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085049-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 86"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 86"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085049-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 87" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085049-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 87"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 87"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085049-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 88" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085049-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 88"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 88"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085049-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 89" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085049-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 89"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 89"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085049-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 90" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085049-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 90"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 90"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085049-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 91" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085049-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 91"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 91"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085049-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 92" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085049-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 92"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 92"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085049-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 93" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085049-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 93"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 93"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085049-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 94" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085049-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 94"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 94"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085049-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 95" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085049-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 95"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 95"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085049-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 96" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085049-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 96"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 96"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085140-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 97" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085140-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 97"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 97"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085140-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 98" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085140-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 98"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 98"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085140-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 99" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085140-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 99"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 99"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085140-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 100" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085140-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 100"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 100"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085140-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 101" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085140-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 101"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 101"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085140-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 102" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085140-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 102"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 102"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085140-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 103" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085140-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 103"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 103"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085140-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 104" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085140-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 104"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 104"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085140-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 105" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085140-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 105"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 105"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085140-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 106" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085140-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 106"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 106"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085140-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 107" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085140-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 107"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 107"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085140-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 108" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085140-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 108"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 108"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085140-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 109" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085140-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 109"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 109"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085140-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 110" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085140-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 110"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 110"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085140-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 111" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085140-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 111"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 111"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085140-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 112" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085140-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 112"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 112"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085213-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 113" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085213-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 113"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 113"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085213-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 114" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085213-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 114"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 114"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085213-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 115" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085213-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 115"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 115"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085213-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 116" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085213-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 116"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 116"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085213-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 117" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085213-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 117"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 117"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085213-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 118" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085213-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 118"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 118"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085213-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 119" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085213-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 119"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 119"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085213-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 120" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085213-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 120"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 120"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085213-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 121" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085213-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 121"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 121"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085213-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 122" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085213-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 122"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 122"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085213-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 123" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085213-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 123"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 123"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085213-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 124" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085213-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 124"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 124"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085213-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 125" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085213-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 125"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 125"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085213-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 126" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085213-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 126"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 126"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085213-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 127" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085213-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 127"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 127"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085213-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 128" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085213-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 128"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 128"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085255-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 129" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085255-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 129"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 129"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085255-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 130" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085255-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 130"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 130"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085255-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 131" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085255-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 131"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 131"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085255-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 132" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085255-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 132"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 132"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085255-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 133" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085255-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 133"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 133"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085255-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 134" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085255-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 134"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 134"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085255-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 135" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085255-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 135"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 135"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085255-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 136" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085255-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 136"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 136"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085255-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 137" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085255-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 137"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 137"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085255-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 138" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085255-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 138"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 138"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085255-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 139" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085255-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 139"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 139"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085255-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 140" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085255-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 140"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 140"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085255-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 141" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085255-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 141"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 141"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085255-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 142" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085255-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 142"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 142"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085255-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 143" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085255-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 143"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 143"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085255-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 144" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085255-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 144"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 144"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085340-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 145" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085340-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 145"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 145"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085340-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 146" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085340-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 146"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 146"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085340-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 147" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085340-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 147"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 147"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085340-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 148" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085340-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 148"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 148"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085340-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 149" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085340-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 149"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 149"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085340-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 150" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085340-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 150"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 150"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085340-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 151" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085340-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 151"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 151"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085340-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 152" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085340-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 152"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 152"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085340-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 153" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085340-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 153"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 153"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085340-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 154" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085340-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 154"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 154"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085340-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 155" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085340-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 155"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 155"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085340-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 156" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085340-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 156"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 156"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085340-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 157" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085340-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 157"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 157"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085340-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 158" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085340-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 158"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 158"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085340-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 159" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085340-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 159"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 159"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085340-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 160" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085340-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 160"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 160"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085416-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 161" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085416-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 161"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 161"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085416-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 162" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085416-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 162"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 162"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085416-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 163" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085416-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 163"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 163"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085416-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 164" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085416-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 164"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 164"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085416-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 165" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085416-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 165"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 165"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085416-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 166" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085416-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 166"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 166"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085416-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 167" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085416-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 167"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 167"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085416-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 168" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085416-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 168"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 168"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085416-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 169" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085416-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 169"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 169"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085416-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 170" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085416-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 170"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 170"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085416-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 171" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085416-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 171"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 171"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085416-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 172" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085416-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 172"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 172"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085416-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 173" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085416-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 173"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 173"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085416-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 174" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085416-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 174"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 174"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085416-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 175" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085416-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 175"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 175"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085416-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 176" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085416-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 176"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 176"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085449-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 177" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085449-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 177"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 177"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085449-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 178" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085449-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 178"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 178"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085449-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 179" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085449-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 179"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 179"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085449-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 180" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085449-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 180"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 180"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085449-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 181" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085449-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 181"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 181"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085449-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 182" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085449-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 182"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 182"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085449-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 183" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085449-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 183"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 183"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085449-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 184" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085449-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 184"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 184"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085449-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 185" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085449-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 185"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 185"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085449-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 186" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085449-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 186"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 186"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085449-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 187" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085449-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 187"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 187"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085449-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 188" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085449-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 188"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 188"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085449-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 189" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085449-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 189"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 189"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085449-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 190" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085449-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 190"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 190"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085449-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 191" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085449-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 191"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 191"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085449-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 192" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085449-17.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 192"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 192"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085529-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 193" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085529-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 193"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 193"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085529-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 194" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085529-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 194"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 194"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085529-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 195" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085529-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 195"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 195"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085529-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 196" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085529-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 196"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 196"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085529-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 197" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085529-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 197"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 197"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085529-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 198" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085529-7.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 198"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 198"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085529-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 199" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085529-8.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 199"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 199"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085529-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 200" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085529-9.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 200"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 200"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085529-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 201" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085529-10.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 201"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 201"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085529-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 202" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085529-11.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 202"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 202"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085529-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 203" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085529-12.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 203"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 203"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085529-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 204" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085529-13.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 204"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 204"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085529-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 205" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085529-14.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 205"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 205"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085529-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 206" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085529-15.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 206"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 206"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085529-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 207" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085529-16.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 207"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 207"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085553-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 208" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085553-2.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 208"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 208"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085553-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 209" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085553-3.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 209"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 209"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085553-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 210" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085553-4.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 210"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 210"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085553-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 211" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085553-5.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 211"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 211"/></a>
					<a href="/uploads/coberturas/XV-Edicao/20130919-085553-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 212" rel="galeria">
				<img src="/uploads/coberturas/XV-Edicao/mini.20130919-085553-6.jpg"
				title="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 212"
				alt="Fotos BIXURRASCO  - XV Edicao - FATEC - 14/09/2013 - Foto 212"/></a>
			</div>
	<script type="text/javascript">
	$(document).ready(function(){
		$("#comum #listaFotos a").fancybox({
			autoScale: false,
			overlayOpacity: 0.9,
			overlayColor: '#000',
			padding: 0,
			margin: 0
		});
	});
	</script>
	
</div>	<br class="clear"/>
</div>

<div id="rodape">
	<div class="limitador">
		<div class="coluna">
			<img src="/img/rodape.logo.gif" />
			<br />
			<a class="block" href="mailto:contato@afterfest.com.br">contato@afterfest.com.br</a>
			<br />
			Copyright 2009 &copy; AfterFest<br />
			Todos os direitos reservados
		</div>
		<div class="coluna">
			<ul class="nav">
								<li class="item">
							<a class="baladas" href="/baladas">baladas</a>
						</li><li class="item">
							<a class="bares" href="/bares">bares</a>
						</li><li class="item">
							<a class="noticias" href="/noticias">noticias</a>
						</li><li class="item">
							<a class="coberturas " href="/coberturas ">coberturas</a>
						</li><li class="item">
							<a class="agenda" href="/agenda">agenda</a>
						</li><li class="item">
							<a class="gatas" href="/gatas">gatas</a>
						</li><li class="item">
							<a class="contato" href="/contato">contatos</a>
						</li><li class="item">
							<a class="cadastro" href="/cadastro">equipe</a>
						</li>			</ul>
		</div>
		<div class="coluna social">
			Siga-nos no
			<a href="http://twitter.com/afterfest" target="_blank"><img src="/img/rodape.twitter.gif" /></a>
			Participe da nossa<br />
			comunidade no
			<a href="http://www.orkut.com.br/Main#Community?cmm=33229667" target="_blank"><img src="/img/rodape.orkut.gif" /></a>
		</div>
	</div>
</div><script type="text/javascript"> 
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script> 
<script type="text/javascript"> 
try {
	var pageTracker = _gat._getTracker("UA-2530999-1");
	pageTracker._trackPageview();
} catch(err) {}
</script> 
</body>
</html>
'''
import urllib.request
tag = '/uploads/coberturas/XV-Edicao/'
site = 'http://afterfest.com.br/'
k = texto.find(tag)
while k != -1:
  j = k + len(tag)
  if texto[j] != 'm': #não é mini foto (thumbnail)
    f = texto.find('"', j)
    print (texto[j:f])
    url = site + texto[k:f]
    foto = urllib.request.urlopen(url).read()
    file = open(texto[j:f], 'wb')
    file.write(foto)
    file.close()
    
  k = texto.find(tag, k + 1)
  
