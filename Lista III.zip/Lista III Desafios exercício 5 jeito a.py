n = input('Número: ')
n = n[::-1]
print (n)
