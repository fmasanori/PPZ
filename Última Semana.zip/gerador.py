def gerador():
  yield 42
  yield 'abacate'
  yield 13
  yield [1, 2, 3]
  
