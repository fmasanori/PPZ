x = 2
y = 5
if y > 8:
    y = y * 2
else:
    x = x * 2
print (x + y)
